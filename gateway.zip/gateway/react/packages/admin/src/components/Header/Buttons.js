function Buttons({children}) {
  return (
    <div className="gty-admin-header__right">
      {children}
    </div>
  );
}

export default Buttons;