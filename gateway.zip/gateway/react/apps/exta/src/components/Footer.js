const Footer = () => {
  return (
    <footer className="px-8 py-3 flex items-center justify-end border-t border-slate-600">
      <span className="text-xs text-slate-500">
        GATEWAY v1.1.11-rc1-dev
      </span>
    </footer>
  );
};

export default Footer;
