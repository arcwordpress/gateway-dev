const Settings = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold !text-slate-200 mb-6">Settings</h1>
      <p className="!text-slate-500">No settings currently for the Gateway Builder.</p>
    </div>
  );
};

export default Settings;
