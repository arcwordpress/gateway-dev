<?php
/**
 * @var array    $attributes Block attributes
 * @var string   $content    Block content
 * @var WP_Block $block      Block instance
 */
?>
<div class="gateway-circle" style="width:100px;height:100px;border-radius:50%;background:blue;">Circle</div>