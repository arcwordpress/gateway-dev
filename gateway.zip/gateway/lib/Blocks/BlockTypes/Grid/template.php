<?php
/**
 * @var array    $attributes Block attributes
 * @var string   $content    Block content
 * @var WP_Block $block      Block instance
 */
?>
<div class="gateway-grid" style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px;">
    <InnerBlocks />
</div>
