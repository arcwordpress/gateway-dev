<?php
/**
 * @var array    $attributes Block attributes
 * @var string   $content    Block content (rendered inner blocks)
 * @var WP_Block $block      Block instance
 */
?>
<div class="gateway-box" style="padding:20px;background:red;color:white;">
    <InnerBlocks />
</div>