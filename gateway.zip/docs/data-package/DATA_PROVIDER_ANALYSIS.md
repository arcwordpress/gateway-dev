# Provider Architecture Analysis

## Current Design

### Two Separate Providers (Independent)

#### 1. **GatewayDataProvider** (Optional Root Configuration Provider)
- **Purpose**: Configure API settings (URL, auth) for all child components
- **Context**: GatewayDataContext (but appears to be **unused**!)
- **State**: Only configuration (`apiUrl`, `auth`)
- **When to use**: Override default API configuration from window globals
- **Design**: Optional wrapper at root level

**Key Finding**: `GatewayDataProvider` creates its own `apiClient` but **nothing actually uses the GatewayDataContext**. The `apiClient.js` service only reads from window globals or passed-in config, not from context.

#### 2. **CollectionProvider** (Collection Data Provider)
- **Purpose**: Manage both collection metadata AND records for a specific collection
- **Context**: CollectionContext
- **State**: 
  - Collection metadata (fields, routes, filters, grid config)
  - Collection records (array of data)
  - Loading/error states for both
  - CRUD operations
- **When to use**: Always, when working with collection data
- **Design**: Per-collection instance

### Relationship Status: **INDEPENDENT**

The two providers are **designed to work independently**:
- `GatewayDataProvider` is optional and only sets configuration
- `CollectionProvider` works standalone, reading directly from window globals
- They do **NOT** communicate with each other
- `GatewayDataProvider` context is never consumed by `CollectionProvider`

## The Problem

### Current Behavior Flow

```
User wants to display public form
  ↓
Form component renders
  ↓
CollectionProvider mounts (or Form.js calls getCollection)
  ↓
fetchCollectionInfo() called
  ↓
API: GET /gateway/v1/collections/{key} ← REQUIRES AUTH
  ↓
❌ 401 Unauthorized (public user has no auth)
  ↓
Cannot get collection.routes.namespace/route
  ↓
Cannot fetch records from public endpoint
```

### Root Cause

**CollectionProvider has a hard dependency on collection metadata** before it can fetch records:

```javascript
// Line 68-72 in CollectionProvider.js
if (!collection?.routes?.namespace || !collection?.routes?.route) {
  // Don't fetch records until we have collection metadata
  return;
}
```

This means:
1. **Always fetches from `/gateway/v1/collections/{key}`** (authenticated endpoint)
2. **Cannot fetch records until metadata is loaded**
3. **No way to bypass metadata fetching** for public endpoints

## Use Cases Analysis

### Use Case 1: Admin/Authenticated (Full CRUD)
**Needs:**
- ✅ Collection metadata (fields, filters, grid config, routes)
- ✅ Records
- ✅ CRUD operations
- ✅ Authentication

**Current Solution:** Works perfectly with `CollectionProvider`

### Use Case 2: Public Forms (Read-Only or Simple Submit)
**Needs:**
- ❌ Collection metadata (just needs to know the endpoint)
- ✅ Records (from public endpoint)
- ✅ Create operation (maybe, for submissions)
- ❌ Authentication

**Current Problem:** Blocked by metadata fetch requirement

### Use Case 3: Public Display (Read-Only)
**Needs:**
- ❌ Collection metadata
- ✅ Records (from public endpoint)
- ❌ CRUD operations
- ❌ Authentication

**Current Problem:** Blocked by metadata fetch requirement

## Solutions to Consider

### Option 1: Add "Direct Mode" to CollectionProvider ⭐ RECOMMENDED

Allow passing route info directly to skip metadata fetch:

```jsx
<CollectionProvider
  collectionKey="events"
  directAccess={{
    namespace: 'gateway/v1',
    route: 'events'
  }}
  skipMetadata={true}
>
  <PublicForm />
</CollectionProvider>
```

**Pros:**
- Minimal changes to existing architecture
- Backwards compatible
- Keeps all logic in one provider
- Can still fall back to metadata fetch if needed

**Cons:**
- Adds complexity to CollectionProvider
- Two modes to maintain

### Option 2: Create Separate RecordsProvider

New lightweight provider for records-only access:

```jsx
<RecordsProvider
  namespace="gateway/v1"
  route="events"
  queryParams={{}}
>
  <PublicForm />
</RecordsProvider>
```

**Pros:**
- Clean separation of concerns
- Simpler code for each provider
- Clear intent (metadata vs records)
- Can optimize each separately

**Cons:**
- Two providers to maintain
- Need to coordinate exports/docs
- Slightly more packages to understand

### Option 3: Make CollectionRoutes Public (NOT RECOMMENDED)

Make `/gateway/v1/collections/{key}` public for GET requests.

**Pros:**
- No code changes needed
- Works immediately

**Cons:**
- ❌ Exposes internal structure
- ❌ Security concern
- ❌ Still unnecessary for public forms
- ❌ Doesn't solve the architectural issue

### Option 4: Hook-Level Solution

Create new hooks that don't require provider:

```jsx
const { records, loading } = usePublicRecords('gateway/v1', 'events');
```

**Pros:**
- Most flexible
- Can be used anywhere
- No provider required

**Cons:**
- No shared state between components
- Loses provider benefits
- Multiple fetches for same data

## Recommendation

**Implement Option 1 + Option 2 together:**

1. **Short term**: Add direct mode to `CollectionProvider` for backwards compatibility
2. **Long term**: Create `RecordsProvider` as the preferred solution for public/simple use cases

### Proposed API

```jsx
// Option A: Full features (authenticated)
<CollectionProvider collectionKey="events">
  <AdminInterface />
</CollectionProvider>

// Option B: Records only with direct access (public)
<RecordsProvider 
  namespace="gateway/v1" 
  route="events"
  queryParams={{ status: 'active' }}
>
  <PublicForm />
</RecordsProvider>

// Option C: Backwards compatible direct mode
<CollectionProvider
  collectionKey="events"
  directMode={{
    namespace: 'gateway/v1',
    route: 'events',
    skipMetadata: true
  }}
>
  <LegacyComponent />
</CollectionProvider>
```

## Implementation Notes

### RecordsProvider Design

Should provide:
- `records` - array of data
- `loading` - boolean
- `error` - string|null
- `refresh()` - reload records
- Optional CRUD if endpoint supports it

Should NOT provide:
- `collection` metadata
- `fields` definitions
- `filters` configuration
- `grid` configuration

### Hooks to Export

```javascript
// From RecordsProvider
export { useRecords } from './hooks/useRecords';

// From CollectionProvider (unchanged)
export { useCollectionInfo } from './hooks/useCollectionInfo';
export { useCollectionRecords } from './hooks/useCollectionRecords';
export { useRecord } from './hooks/useRecord';
```

## Migration Path

1. **Phase 1**: Create `RecordsProvider` and `useRecords` hook
2. **Phase 2**: Update public form components to use `RecordsProvider`
3. **Phase 3**: Document patterns for when to use each provider
4. **Phase 4**: (Optional) Add deprecation warnings for authenticated metadata fetches from public contexts

## Questions to Answer

1. **Do public forms need ANY metadata?** 
   - If yes, what metadata? (fields for validation?)
   - Could this be passed as props instead?

2. **Should RecordsProvider support CRUD?**
   - Or should it be read-only?
   - Maybe separate `ReadOnlyRecordsProvider` vs `RecordsProvider`?

3. **What about authentication for RecordsProvider?**
   - Should it support optional auth for semi-public endpoints?
   - Or strictly public only?

4. **Should we keep GatewayDataProvider?**
   - It's currently unused
   - Could be useful for future multi-tenant scenarios
   - Or remove to simplify?
